void applyListingRobots(bool noIndex) {}
